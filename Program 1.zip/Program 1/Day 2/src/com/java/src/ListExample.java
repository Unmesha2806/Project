package com.java.src;

import java.util.ArrayList;

public class ListExample {
	
	public static void main(String[] args) {
		
	
	
	ArrayList<String> data = new ArrayList<>();
	
	data.add("Mamunu");
	data.add("Katunu");
	data.add("Runu");
	data.add("Chagala");
	
	data.remove("Runu");
	
	
	System.out.println(data);

	}
}
