// Java Program to print Multiplication of two floating point Number.
 


package com.java.src; //Here a package keyword is being used 

public class Main { // declaration of a class named "Main." 
	
	
	    public static void main(String[] args) // declaration of the Main class, which contains the main method, the entry point for the program.
		
	    {
	 
	        // f is to ensures that numbers are float data type
	        float f1 = 1.5f;
	        float f2 = 2.0f;
	 
	        // to store the multiplied value
	        float p = f1 * f2;
	 
	        // to print the product
	        System.out.println("The product is: " + p);
	    }
	}


