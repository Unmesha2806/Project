
//Java Program to demonstrate String


package com.java.src;

public class StringExample {  // declaration of a class named "StringExample"
	
	
    public static void main(String args[]) //Main Function
    {
        String str = new String("My Name is Unmesha");
        // creating Java string by new keyword
        // this statement create two object i.e
        // first the object is created in heap
        // memory area and second the object is
        // created in String constant pool.
 
        System.out.println(str); // print the result
    }
}


