
 //  WAP a Java program that demonstrates how to handle an ArithmeticException using a try-catch block


package com.java.src;

public class ArithmeticExp {
	
	public static void main(String[] args) {
		
		 // Declare and initialize an integer array 'arr' with values 2, 3, and 5.
		
		int arr[] = new int [] {2,3,5};
		try {
			
			// Attempt to divide arr[2] by 0, which will result in an ArithmeticException.
			
			int a = arr[2]/0;
			
		} catch (ArithmeticException e) {
			
			// TODO Auto-generated catch block
			
			// Catch the ArithmeticException if it occurs and execute the code inside this block.
			
			System.out.println("Cannnot be Divisible...");
		}
	}
}


