package com.java.hello;

import java.util.LinkedHashSet;
import java.util.Set;

public class SetExample {
	
	public static void main(String[] args) {
		
		
		
			Set<String> data = new LinkedHashSet<>();
			
			
			
			
			data.add("Java");
			data.add("Set");
			data.add("Example");
		    data.add("Programming");
		    System.out.println(data);
			
			

			
			
			
		}
		    


	}

	
