package com.java.jsp;

public class Dummy {

	public static void main(String[] args) {
		ProviderDaoImpl dao = new ProviderDaoImpl();
		String newId = ProviderDaoImpl.generateproviderID();
		System.out.println(newId);
	}
}
