package com.java.jsp;

public interface ProviderDao {
	
	String addProvider(Provider provider);
	

}
