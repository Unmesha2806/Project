//WAP to print number of elements in an array

package com.java.src;

public class Main {
  public static void main(String[] args) {
	  
    //Initializing an int array
    int [] numbers = new int [] {2, 4, 6, 8, 10, 12};
    
    // We can use length property of array to find the count of elements
    
    System.out.println("Number of elements in the given int array: " + numbers.length);
    
    

    //Initializing a String array
    String [] names = new String [] {"Rick", "Luna", "Steve", "John"};
    
    System.out.println("Number of elements in the given String array: " + names.length);
  }
}